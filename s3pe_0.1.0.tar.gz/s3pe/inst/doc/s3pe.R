## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", eval = FALSE)

## -----------------------------------------------------------------------------
# library(s3pe)
# s3_config()
# 
# cfg <- s3_config(bucket = "horizonte-fiscal",
#                  access_key = Sys.getenv("HF_KEY"),
#                  secret_key = Sys.getenv("HF_SECRET"))

## -----------------------------------------------------------------------------
# # JSON -> list
# meta <- read_s3("dados/metadata.json")
# meta$ultimo_mes
# 
# # gzipped CSV -> tibble (readr); `...` reaches the reader
# icms <- read_s3("s3://horizonte-fiscal/series/estado/icms.csv.gz",
#                 col_types = "Dncl")
# 
# # GeoJSON -> sf, when sf is installed
# municipios <- read_s3("dados/pe_municipios.geojson")
# 
# # Parquet -> data frame (nanoparquet)
# painel <- read_s3("etl/painel_iaempe.parquet")
# 
# # anything else -> raw bytes; or ask for them
# png <- read_s3("nota_tecnica/figura1.png")
# txt <- read_s3("dados/metadata.json", format = "text")

## -----------------------------------------------------------------------------
# cache <- "iaem-cache.rds"
# meta <- read_s3("dados/metadata.json")
# if (!file.exists(cache) || readRDS(cache)$ultimo_mes != meta$ultimo_mes) {
#   batch <- list(
#     ultimo_mes = meta$ultimo_mes,
#     series = read_s3("dados/series.json"),
#     ranking = read_s3("dados/ranking.json")
#   )
#   saveRDS(batch, cache)
# }

## -----------------------------------------------------------------------------
# write_s3(painel, "nota_tecnica/painel.parquet")
# write_s3(painel, "nota_tecnica/painel.csv.gz")
# write_s3(list(gerado_em = Sys.time(), linhas = nrow(painel)),
#          "nota_tecnica/manifest.json", pretty = TRUE)
# write_s3(modelo, "nota_tecnica/modelo.rds")
# write_s3(c("# Nota técnica", "", "Texto..."), "nota_tecnica/README.md")

## -----------------------------------------------------------------------------
# upload_s3("output/figura1.png", "nota_tecnica/")
# download_s3("dados/pe_municipios.geojson", "data/pe_municipios.geojson",
#             overwrite = TRUE)

## -----------------------------------------------------------------------------
# list_s3("dados/")                     # tibble: key, size, last_modified, etag
# head_s3("dados/metadata.json")        # one row, or NULL
# exists_s3("dados/metadata.json")      # TRUE/FALSE
# delete_s3("nota_tecnica/rascunho.csv")
# buckets_s3()

## -----------------------------------------------------------------------------
# meta <- tryCatch(
#   read_s3("dados/metadata.json"),
#   s3pe_error_not_found = function(e) NULL
# )

## -----------------------------------------------------------------------------
# options(s3pe.endpoint = "http://127.0.0.1:9003")

